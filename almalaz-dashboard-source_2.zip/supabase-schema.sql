-- شغّل هذا الكود في Supabase: لوحة التحكم -> SQL Editor -> New query -> الصق والتشغيل (Run)
-- هذا الملف آمن لإعادة التشغيل أكثر من مرة (لن يعطي أخطاء تكرار).

create table if not exists transactions (
  id text primary key,
  type text not null,
  partner text not null,
  category text,
  amount numeric not null,
  date date not null,
  reference text default '',
  note text default '',
  attachment jsonb,
  locked boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- تفعيل الوصول العلني عبر مفتاح anon (راجع قسم "ملاحظة أمان مهمة" في README)
alter table transactions enable row level security;

drop policy if exists "Public read access" on transactions;
create policy "Public read access" on transactions
  for select using (true);

drop policy if exists "Public insert access" on transactions;
create policy "Public insert access" on transactions
  for insert with check (true);

drop policy if exists "Public update access" on transactions;
create policy "Public update access" on transactions
  for update using (true);

drop policy if exists "Public delete access" on transactions;
create policy "Public delete access" on transactions
  for delete using (true);

-- تفعيل التحديث اللحظي (Realtime) — يتجاهل الخطأ إذا كان الجدول مضافًا مسبقًا
do $$
begin
  alter publication supabase_realtime add table transactions;
exception
  when duplicate_object then null;
end $$;

-- جدول إعدادات المشروع المشتركة (حاليًا: تكلفة الإشراف القابلة للتعديل)
-- صف واحد ثابت (id = 1) يُحدَّث بدل إضافة صفوف جديدة
create table if not exists project_settings (
  id int primary key default 1,
  supervision_cost numeric not null default 0,
  updated_at timestamptz default now(),
  constraint single_row check (id = 1)
);

insert into project_settings (id, supervision_cost)
values (1, 0)
on conflict (id) do nothing;

alter table project_settings enable row level security;

drop policy if exists "Public read settings" on project_settings;
create policy "Public read settings" on project_settings
  for select using (true);

drop policy if exists "Public update settings" on project_settings;
create policy "Public update settings" on project_settings
  for update using (true);

do $$
begin
  alter publication supabase_realtime add table project_settings;
exception
  when duplicate_object then null;
end $$;

-- ============================================================
-- نظام تسجيل دخول بسيط (اسم مستخدم + كلمة مرور لكل طرف)
-- ============================================================
create table if not exists app_users (
  username text primary key,
  password text not null,
  display_name text not null,
  partner_id text not null, -- 'saeed' | 'ibrahim' | 'contractor'
  created_at timestamptz default now()
);

-- لا نمنح أي صلاحية قراءة مباشرة لجدول المستخدمين عبر المفتاح العلني (anon key)
-- حتى لا تكون كلمات المرور قابلة للقراءة من المتصفح. الدخول الوحيد لهذا الجدول
-- هو عبر الدالة login_app_user أدناه، التي تُشغَّل بصلاحيات خاصة (security definer)
alter table app_users enable row level security;
-- (عمدًا: لا توجد أي policy هنا، أي لا وصول عام مباشر للجدول)

create or replace function login_app_user(p_username text, p_password text)
returns table(display_name text, partner_id text)
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
    select u.display_name, u.partner_id
    from app_users u
    where u.username = p_username and u.password = p_password;
end;
$$;

-- السماح لأي زائر (حتى بدون تسجيل دخول) باستدعاء دالة تسجيل الدخول نفسها فقط
grant execute on function login_app_user(text, text) to anon;

-- ============================================================
-- عدّل أسماء المستخدمين وكلمات المرور هنا قبل التشغيل، أو غيّرها
-- لاحقًا من SQL Editor بأمر: update app_users set password = '...' where username = '...';
-- ============================================================
insert into app_users (username, password, display_name, partner_id) values
  ('saeed',    'change-me-1', 'سعيد الغامدي',     'saeed'),
  ('ibrahim',  'change-me-2', 'إبراهيم الخنيزان', 'ibrahim'),
  ('abdullah', 'change-me-3', 'عبدالله الغامدي',  'contractor')
on conflict (username) do nothing;
