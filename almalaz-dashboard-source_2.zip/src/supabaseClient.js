import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  // eslint-disable-next-line no-console
  console.warn(
    "بيانات Supabase غير موجودة. أضف VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY في ملف .env محليًا، وفي إعدادات Environment variables في Netlify."
  );
}

export const supabase = createClient(supabaseUrl || "", supabaseAnonKey || "");

export const TRANSACTIONS_TABLE = "transactions";
export const SETTINGS_TABLE = "project_settings";

// تسجيل الدخول: يستدعي دالة قاعدة بيانات تتحقق من اسم المستخدم وكلمة المرور
// بدون كشف كلمات المرور نفسها للمتصفح أبدًا
export async function loginAppUser(username, password) {
  const { data, error } = await supabase.rpc("login_app_user", {
    p_username: username,
    p_password: password,
  });
  if (error) throw error;
  if (!data || data.length === 0) return null;
  return data[0]; // { display_name, partner_id }
}
